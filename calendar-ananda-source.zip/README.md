#React-Redux Calendar app with ability to 
    - display all months and days of a year
    - mark days as Holiday, Busy, Birthday and Anniversary.
    - navigate between years and back to current year.
#Author: Ananda Mohanram
#Date: 21 Nov 2018 18:30

 Created with create-reat-app
 moment.js library used for calendar.
 demonstrates use of redux
 reduced usage of smart components
 
 #Todo
 Can replace moment.js library with day.js to reduce chunk size.
 Can add drop down to navigate between years.
 Can write more tests.
